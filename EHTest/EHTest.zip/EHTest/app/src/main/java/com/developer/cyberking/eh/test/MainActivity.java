package com.developer.cyberking.eh.test;

import android.app.Activity;
import android.os.Bundle;
import com.cyberking.developer.eh.EH;

public class MainActivity extends Activity {

  @Override
  protected void onCreate (Bundle savedInstanceState) {
    new EH.Builder (getApplicationContext ())
      .init ();

    super.onCreate (savedInstanceState);
    setContentView (R.layout.main);
  }
}
